<template>
	<h1>The Portfolio - Stock Component</h1>
</template>