<template>
	<div class="col-sm-6 col-md-4">
		<div class="panel panel-success">
			<div class="panel-heading">
				<h3 class="panel-tile">
				NAME
				<small>(Price: PRICE)</small>
			</h3>
			</div>
			<div class="panel-body">
				<div class="pull-left">
					<input type="number" class="form-control" placeholder="Quantidade">
				</div>
				<div class="pull-right"
				>
					<button class="btn btn-success">
						Comprar
					</button>
				</div>
			</div>
		</div>
	</div>
</template>