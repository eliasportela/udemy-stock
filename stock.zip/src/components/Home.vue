<template>
	<h1>The Home Component</h1>
</template>